package com.leo.manutencao;

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.*;
import java.util.*;

public class WorkOrderActivity extends Activity {
    private EditText machine, description, solution, orderId;
    private LinearLayout list;
    private FirebaseFirestore db;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b); db=FirebaseFirestore.getInstance();
        LinearLayout p=Ui.page(this);p.addView(Ui.heading(this,"Ordens de serviço"));
        machine=Ui.input(this,"ID da máquina");p.addView(machine);
        description=Ui.input(this,"Descrição da falha/serviço");p.addView(description);
        Button open=Ui.button(this,"Abrir OS"); open.setOnClickListener(v->open()); p.addView(open);
        orderId=Ui.input(this,"ID da OS para concluir");p.addView(orderId);
        solution=Ui.input(this,"Solução executada");p.addView(solution);
        Button close=Ui.button(this,"Concluir OS"); close.setOnClickListener(v->closeOrder()); p.addView(close);
        Button refresh=Ui.button(this,"Atualizar lista"); refresh.setOnClickListener(v->load()); p.addView(refresh);
        Button back=Ui.button(this,"Voltar"); back.setOnClickListener(v->finish()); p.addView(back);
        list=new LinearLayout(this);list.setOrientation(1);p.addView(list);
        setContentView(p);load();
    }
    private void open(){
        String mid=machine.getText().toString().trim(), desc=description.getText().toString().trim(), uid=FirebaseAuth.getInstance().getUid();
        if(mid.isEmpty()||desc.isEmpty()){Ui.message(this,"Informe máquina e descrição.");return;}
        if(uid==null){Ui.message(this,"Faça login novamente.");return;}
        Map<String,Object> d=new HashMap<>();d.put("machineId",mid);d.put("description",desc);d.put("status","ABERTA");d.put("openedBy",uid);d.put("openedAt",FieldValue.serverTimestamp());
        db.collection("work_orders").add(d).addOnSuccessListener(ref->{orderId.setText(ref.getId());Ui.message(this,"OS aberta: "+ref.getId());load();})
        .addOnFailureListener(e->Ui.message(this,"Erro: "+e.getLocalizedMessage()));
    }
    private void closeOrder(){
        String oid=orderId.getText().toString().trim(), sol=solution.getText().toString().trim();
        if(oid.isEmpty()||sol.isEmpty()){Ui.message(this,"Informe ID da OS e solução.");return;}
        DocumentReference ref=db.collection("work_orders").document(oid);
        ref.update("status","CONCLUIDA","solution",sol,"closedAt",FieldValue.serverTimestamp(),"closedBy",FirebaseAuth.getInstance().getUid())
        .addOnSuccessListener(x->{Ui.message(this,"OS concluída.");load();})
        .addOnFailureListener(e->Ui.message(this,"Erro ao concluir: "+e.getLocalizedMessage()));
    }
    private void load(){
        db.collection("work_orders").orderBy("openedAt",Query.Direction.DESCENDING).limit(30).get()
        .addOnSuccessListener(q->{list.removeAllViews();for(DocumentSnapshot d:q){
            TextView t=new TextView(this);t.setPadding(0,10,0,10);
            t.setText(d.getId()+" | "+d.getString("machineId")+" | "+d.getString("status")+"\n"+d.getString("description"));
            list.addView(t);
        }}).addOnFailureListener(e->Ui.message(this,"Falha ao listar OS: "+e.getLocalizedMessage()));
    }
}
