package com.leo.manutencao;

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.*;
import java.util.*;

public class StopActivity extends Activity {
    private EditText machine, reason, details;
    private FirebaseFirestore db;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b); db=FirebaseFirestore.getInstance();
        LinearLayout p=Ui.page(this);p.addView(Ui.heading(this,"Parada crítica expressa"));
        machine=Ui.input(this,"ID da máquina");p.addView(machine);
        reason=Ui.input(this,"Motivo (ELÉTRICA, MECÂNICA...)");p.addView(reason);
        details=Ui.input(this,"Descrição do problema");p.addView(details);
        p.addView(Ui.button(this,"Registrar parada")).setOnClickListener(v->openStop());
        p.addView(Ui.button(this,"Voltar")).setOnClickListener(v->finish());
        setContentView(p);
    }
    private void openStop(){
        String mid=machine.getText().toString().trim(), r=reason.getText().toString().trim(), desc=details.getText().toString().trim();
        if(mid.isEmpty()||r.isEmpty()){Ui.message(this,"Informe máquina e motivo.");return;}
        String uid=FirebaseAuth.getInstance().getUid();
        if(uid==null){Ui.message(this,"Faça login novamente.");return;}
        DocumentReference m=db.collection("machines").document(mid);
        DocumentReference stop=db.collection("stops").document();
        DocumentReference os=db.collection("work_orders").document();
        db.runTransaction(tx->{
            DocumentSnapshot ms=tx.get(m);
            if(!ms.exists()) throw new IllegalStateException("Máquina não cadastrada.");
            if("BLOQUEADA".equals(ms.getString("status"))) throw new IllegalStateException("Máquina já está bloqueada.");
            Map<String,Object> data=new HashMap<>();
            data.put("machineId",mid);data.put("reason",r);data.put("description",desc);
            data.put("status","ABERTA");data.put("openedBy",uid);data.put("openedAt",FieldValue.serverTimestamp());
            Map<String,Object> order=new HashMap<>(data);order.put("type","PARADA_CRITICA");
            tx.set(stop,data);tx.set(os,order);tx.update(m,"status","BLOQUEADA");
            return os.getId();
        }).addOnSuccessListener(osId->Ui.message(this,"Parada registrada. OS: "+osId))
          .addOnFailureListener(e->Ui.message(this,"Não foi possível registrar: "+e.getLocalizedMessage()));
    }
}
