package com.leo.manutencao;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.text.TextUtils;
import android.widget.*;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends Activity {
    private EditText email, password;
    private FirebaseAuth auth;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        auth = FirebaseAuth.getInstance();
        if (auth.getCurrentUser()!=null) { openHome(); return; }
        LinearLayout page=Ui.page(this);
        page.addView(Ui.heading(this,"APP LÉO"));
        TextView sub=new TextView(this); sub.setText("Manutenção industrial"); page.addView(sub);
        email=Ui.input(this,"E-mail"); email.setInputType(33); page.addView(email);
        password=Ui.input(this,"Senha"); password.setInputType(129); page.addView(password);
        Button login=Ui.button(this,"Entrar"); page.addView(login);
        Button register=Ui.button(this,"Criar primeira conta"); page.addView(register);
        setContentView(page);
        login.setOnClickListener(v -> signIn());
        register.setOnClickListener(v -> createAccount());
    }
    private void signIn() {
        String e=email.getText().toString().trim(), p=password.getText().toString();
        if(TextUtils.isEmpty(e)||p.length()<6){Ui.message(this,"Informe e-mail e senha com pelo menos 6 caracteres.");return;}
        FirebaseAuth.getInstance().signInWithEmailAndPassword(e,p)
            .addOnSuccessListener(r->openHome())
            .addOnFailureListener(err->Ui.message(this,"Falha no login: "+err.getLocalizedMessage()));
    }
    private void createAccount() {
        String e=email.getText().toString().trim(), p=password.getText().toString();
        if(TextUtils.isEmpty(e)||p.length()<6){Ui.message(this,"Informe e-mail e senha com pelo menos 6 caracteres.");return;}
        auth.createUserWithEmailAndPassword(e,p).addOnSuccessListener(r->{
            String uid=r.getUser().getUid();
            com.google.firebase.firestore.FirebaseFirestore.getInstance()
                .collection("users").document(uid)
                .set(new java.util.HashMap<String,Object>() {{
                    put("email",e); put("role","PENDENTE"); put("createdAt",com.google.firebase.firestore.FieldValue.serverTimestamp());
                }})
                .addOnSuccessListener(x->{Ui.message(this,"Conta criada. Um administrador precisa liberar seu acesso no Firebase.");openHome();})
                .addOnFailureListener(err->Ui.message(this,"Conta criada, mas perfil não foi salvo: "+err.getLocalizedMessage()));
        }).addOnFailureListener(err->Ui.message(this,"Falha ao criar conta: "+err.getLocalizedMessage()));
    }
    private void openHome(){startActivity(new Intent(this,MainActivity.class));finish();}
}
