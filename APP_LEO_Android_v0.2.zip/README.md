# APP LÉO — versão 0.2.0

Projeto novo, independente do RVTEC.

## O que já foi implementado no código
- Login e criação da primeira conta (primeira conta recebe perfil ADMIN).
- Inicialização Firebase e App Check (Debug em builds debug; Play Integrity em release).
- Cadastro/listagem de máquinas.
- Abertura de OS e listagem das últimas 30 OS.
- Conclusão básica de OS.
- Abertura expressa de parada crítica com transação Firestore, bloqueando máquina e criando OS.
- Regras iniciais de Firestore em `firestore.rules`.

## Configuração obrigatória
1. No Firebase Console, crie um projeto.
2. Registre aplicativo Android com pacote `com.leo.manutencao`.
3. Baixe `google-services.json` e coloque em `app/google-services.json`.
4. Ative Email/Password em Authentication.
5. Crie Firestore Database.
6. Publique as regras de `firestore.rules`.
7. Ative App Check: Debug para desenvolvimento e Play Integrity para distribuição. Registre o token de debug mostrado no Logcat no Firebase Console.
8. Ative Storage quando for implementar fotos/anexos.
9. Para Gemini, configure Firebase AI Logic no Console e adicione as regras de uso e tratamento de dados antes de habilitar a IA.

## Importante
- Não foi possível compilar ou executar o APK neste ambiente.
- O projeto ainda requer `google-services.json` e configuração do Firebase para funcionar.
- O perfil inicial ADMIN é apenas um bootstrap de primeiro usuário; não é um fluxo seguro de criação de outros administradores. A criação de usuários da equipe deve ser feita por backend/Cloud Functions com autorização.
- As regras fornecidas são uma base inicial e devem ser revisadas antes de uso em produção.
- Ainda faltam: controle de estoque e baixa transacional, permissões completas por função, QR Code, fotos e anexos, preventivas, compras, offline com fila de sincronização, assinatura digital, relatórios e integração Gemini.
