package com.leo.manutencao;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.widget.*;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout page=Ui.page(this);
        page.addView(Ui.heading(this,"APP LÉO"));
        TextView sub=new TextView(this); sub.setText("Gestão de manutenção industrial"); page.addView(sub);
        Button machines=Ui.button(this,"Máquinas");
        machines.setOnClickListener(v->startActivity(new Intent(this,MachineActivity.class))); page.addView(machines);
        Button orders=Ui.button(this,"Ordens de serviço");
        orders.setOnClickListener(v->startActivity(new Intent(this,WorkOrderActivity.class))); page.addView(orders);
        Button stop=Ui.button(this,"Parada crítica expressa");
        stop.setOnClickListener(v->startActivity(new Intent(this,StopActivity.class))); page.addView(stop);
        Button logout=Ui.button(this,"Sair");
        logout.setOnClickListener(v->{FirebaseAuth.getInstance().signOut();startActivity(new Intent(this,LoginActivity.class));finish();}); page.addView(logout);
        setContentView(page);
    }
}
