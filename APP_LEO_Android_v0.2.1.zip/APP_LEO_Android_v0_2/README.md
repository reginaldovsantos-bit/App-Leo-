# APP LÉO — Android v0.2.1

Projeto independente do RVTEC. Aplicativo Android Java com Firebase Authentication e Cloud Firestore.

## O que existe nesta versão
- Login e criação de conta (contas novas ficam como `PENDENTE`).
- Cadastro e consulta de máquinas (somente ADMIN, conforme regras).
- Abertura de ordem de serviço.
- Registro de parada crítica, criação automática de OS e bloqueio da máquina em uma transação Firestore.
- Workflow GitHub Actions para compilar APK de depuração.

## Importante — Firebase
O workflow usa um `google-services.json` temporário apenas para verificar a compilação. Esse arquivo NÃO conecta o app a um projeto Firebase real. Para usar os recursos online, crie um projeto Firebase, registre o app Android `com.leo.manutencao`, baixe o `google-services.json` real e coloque em `app/`. Não publique chaves privadas nem arquivos de service account.

Ative no Firebase Authentication o provedor E-mail/Senha e crie o Firestore. Publique `firestore.rules`.

### Primeiro administrador
1. Crie a primeira conta no aplicativo.
2. No Firebase Console > Firestore Database > `users` > documento com o UID da conta, altere `role` de `PENDENTE` para `ADMIN`.
3. Saia e entre novamente. Nunca permita que o app defina `ADMIN` livremente durante o cadastro.

## Compilar pelo celular usando GitHub Actions
1. Crie um repositório GitHub vazio chamado `APP-LEO`.
2. Envie o conteúdo desta pasta para a branch `main`, mantendo a pasta `.github/workflows`.
3. Abra a aba Actions > `Build APP LEO APK` > `Run workflow`.
4. Quando terminar, abra a execução e baixe o artefato `app-leo-debug-apk`.

## Limitações conhecidas
Esta é uma base inicial, não uma versão pronta para produção. Ainda faltam controle de permissões por perfil em todas as telas, baixa de estoque ao concluir OS, anexos, QR Code, operação offline e testes em dispositivo. O APK de CI é para teste e não terá conexão com seu Firebase até configurar o arquivo real.
