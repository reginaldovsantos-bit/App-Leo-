package com.leo.manutencao;

import android.content.Context;
import android.graphics.Typeface;
import android.view.ViewGroup;
import android.widget.*;
import android.graphics.Color;

public final class Ui {
    private Ui() {}
    public static LinearLayout page(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(36, 28, 36, 28);
        l.setBackgroundColor(Color.rgb(243,245,248));
        return l;
    }
    public static TextView heading(Context c, String s) {
        TextView t = new TextView(c); t.setText(s); t.setTextSize(25);
        t.setTextColor(Color.rgb(16,42,67)); t.setTypeface(null, Typeface.BOLD);
        t.setPadding(0,0,0,20); return t;
    }
    public static EditText input(Context c, String hint) {
        EditText e = new EditText(c); e.setSingleLine(true); e.setHint(hint);
        e.setTextSize(16); e.setPadding(20,12,20,12);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2);
        p.bottomMargin = 12; e.setLayoutParams(p); return e;
    }
    public static Button button(Context c, String text) {
        Button b = new Button(c); b.setText(text);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2);
        p.bottomMargin = 8; b.setLayoutParams(p); return b;
    }
    public static void gap(LinearLayout l, int h) {
        TextView v = new TextView(l.getContext());
        v.setHeight(h); l.addView(v);
    }
    public static void message(Context c, String s) {
        Toast.makeText(c,s,Toast.LENGTH_LONG).show();
    }
}
