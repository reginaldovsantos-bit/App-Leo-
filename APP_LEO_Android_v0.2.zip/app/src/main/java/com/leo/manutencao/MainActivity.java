package com.leo.manutencao;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.widget.*;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout page=Ui.page(this);
        page.addView(Ui.heading(this,"APP LÉO"));
        TextView sub=new TextView(this); sub.setText("Gestão de manutenção industrial"); page.addView(sub);
        page.addView(Ui.button(this,"Máquinas")).setOnClickListener(v->startActivity(new Intent(this,MachineActivity.class)));
        page.addView(Ui.button(this,"Ordens de serviço")).setOnClickListener(v->startActivity(new Intent(this,WorkOrderActivity.class)));
        page.addView(Ui.button(this,"Parada crítica expressa")).setOnClickListener(v->startActivity(new Intent(this,StopActivity.class)));
        page.addView(Ui.button(this,"Sair")).setOnClickListener(v->{FirebaseAuth.getInstance().signOut();startActivity(new Intent(this,LoginActivity.class));finish();});
        setContentView(page);
    }
}
