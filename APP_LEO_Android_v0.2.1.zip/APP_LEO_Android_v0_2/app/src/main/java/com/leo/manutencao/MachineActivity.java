package com.leo.manutencao;

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;
import com.google.firebase.firestore.*;
import java.util.HashMap;
import java.util.Map;

public class MachineActivity extends Activity {
    private EditText id,name,sector;
    private LinearLayout list;
    private FirebaseFirestore db;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b); db=FirebaseFirestore.getInstance();
        LinearLayout p=Ui.page(this); p.addView(Ui.heading(this,"Máquinas"));
        id=Ui.input(this,"Identificação (ex.: EXTR-01)"); p.addView(id);
        name=Ui.input(this,"Nome da máquina"); p.addView(name);
        sector=Ui.input(this,"Setor"); p.addView(sector);
        Button save=Ui.button(this,"Cadastrar máquina"); save.setOnClickListener(v->save()); p.addView(save);
        Button back=Ui.button(this,"Voltar"); back.setOnClickListener(v->finish()); p.addView(back);
        TextView h=new TextView(this); h.setText("Máquinas cadastradas"); p.addView(h);
        list=new LinearLayout(this); list.setOrientation(1); p.addView(list);
        setContentView(p); load();
    }
    private void save() {
        String key=id.getText().toString().trim(), n=name.getText().toString().trim(), s=sector.getText().toString().trim();
        if(key.isEmpty()||n.isEmpty()||s.isEmpty()){Ui.message(this,"Preencha identificação, nome e setor.");return;}
        Map<String,Object> m=new HashMap<>(); m.put("machineId",key);m.put("name",n);m.put("sector",s);m.put("status","OPERANDO");m.put("createdAt",FieldValue.serverTimestamp());
        db.collection("machines").document(key).set(m,SetOptions.merge())
          .addOnSuccessListener(x->{Ui.message(this,"Máquina salva.");id.setText("");name.setText("");sector.setText("");load();})
          .addOnFailureListener(e->Ui.message(this,"Erro: "+e.getLocalizedMessage()));
    }
    private void load() {
        db.collection("machines").orderBy("name").get().addOnSuccessListener(q->{
            list.removeAllViews();
            for(DocumentSnapshot d:q.getDocuments()){
                TextView t=new TextView(this);
                t.setPadding(0,12,0,12);
                t.setText(d.getId()+" — "+d.getString("name")+" | "+d.getString("sector")+" | "+d.getString("status"));
                list.addView(t);
            }
        }).addOnFailureListener(e->Ui.message(this,"Falha ao carregar máquinas: "+e.getLocalizedMessage()));
    }
}
